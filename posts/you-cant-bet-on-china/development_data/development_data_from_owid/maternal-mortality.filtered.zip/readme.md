# Maternal mortality ratio - Data package

This data package contains the data that powers the chart ["Maternal mortality ratio"](https://ourworldindata.org/grapher/maternal-mortality?tab=line&country=~CHN&v=1&csvType=filtered&useColumnShortNames=false) on the Our World in Data website.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:
- country: , CHN
- tab: line

## CSV structure

Each row is an observation for an entity (usually a country or region) at a timepoint.

- "Entity" — the name of the entity, e.g. "United States".
- "Code" — our internal entity code. For most countries this is the [ISO alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code, e.g. "USA"; historical and other non-standard entities get a custom code.
- "Year" or "Day" — the timepoint. Annual data has a "Year" column holding an integer year; otherwise a "Day" column holds a date string in the form "YYYY-MM-DD".
- Every remaining column is a data column, each one a time series. Downloaded with the "full data" option each corresponds to one time series below; with "only selected data visible in the chart" they are transformed depending on the chart type, so the correspondence may be less direct.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc.

## How we process data at Our World in Data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stitch together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

Preparing this data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/).

## Detailed information about each time series


### Maternal mortality ratio
Estimated number of women who die from maternal conditions per 100,000 live births, based on data from death certificates, large-scale surveys, and statistical modeling.
Last updated: July 8, 2024  
Next expected update: November 2026  
Date range: 1751–2020  
Unit: deaths per 100,000 live births  
Source: UN MMEIG (2023); WHO Mortality Database (2025); UN, World Population Prospects (2024); Gapminder (2010) – with major processing by Our World in Data  

#### How to cite this data

UN MMEIG (2023) and other sources – with major processing by Our World in Data

#### What you should know about this data
Maternal deaths are defined as a death of a woman while pregnant or within 42 days of termination of pregnancy, irrespective of the duration and site of pregnancy,
from any cause related or aggravated by the pregnancy or its management, but not from accidental or incidental causes.

#### Notes on our processing step for this indicator
- The dataset combines three sources: WHO Mortality Database (before 1985), Gapminder (before 1985, if WHO Mortality Database data are unavailable), UN MMEIG (1985 onwards).
  The WHO Mortality Database and Gapminder contain reported figures from countries, and are likely to underestimate the true maternal mortality figures. The UN MMEIG aims to estimates the true rate, by adjusting for underreporting and misclassification. Sudden jumps in mortality rate in 1985 are a consequence of switching data sources (from reported to estimated figures).
- For the years between 1950 - 1985 we calculated the maternal mortality ratio and maternal mortality rate based
  on the number of maternal deaths from the WHO mortality database and live births and female population of reproductive age from the UN WPP.
- Where the reported maternal deaths in the WHO Mortality Database differed significantly from the estimated figures in the UN MMEIG data, we opted not to include them.
- Where a data point is attached to a range of years in the Gapminder data set, we used the midpoint of the range.
- The UN MMEIG data shown (post 1985) is the point estimate - this means there is a 50% chance that the true measure lies above this point,
  and a 50% chance that the true value lies below this point.
- We calculated regional aggregates by summing the maternal deaths and live births of all countries in the region and then calculating the MMR based on these figures.


### World region according to OWID
Regions defined by Our World in Data, which are used in OWID charts and maps.
Last updated: January 1, 2023  
Date range: 2023–2023  
Source: Our World in Data  

#### How to cite this data

Our World in Data


## Sources

These are the sources behind the data in this package. Each time series above names the ones it draws on in its citation.

### UN MMEIG (WHO, UNICEF, UNFPA, World Bank Group and UNDESA/ Population Division) – Trends in maternal mortality

The United Nations Maternal Mortality Estimation Inter-Agency Group (MMEIG) – comprising WHO, the United Nations Children’s Fund (UNICEF), the United Nations Population Fund (UNFPA), the World Bank Group and the United Nations Department of Economic and Social Affairs, Population Division (UNDESA/Population Division) has collaborated with external technical experts on a new round of estimates covering 2000 to 2020, in addition to the previous data covering 1985 to 2000. The estimates represent the most up to date, internationally-comparable MMEIG estimates of maternal mortality, using refined input data and methods from previous rounds.

Producer: UN MMEIG (WHO, UNICEF, UNFPA, World Bank Group and UNDESA/ Population Division)  
Published: 2023-02-23  
Retrieved on: 2024-07-08  
Retrieved from: https://www.who.int/publications/i/item/9789240068759  
Direct download: https://srhdpeuwpubsa.blob.core.windows.net/whdh/SRHIHS/Gold/data.zip  
License: CC BY-NC-SA 3.0 IGO. (https://creativecommons.org/licenses/by-nc-sa/3.0/igo/deed.en)  

Citation: Trends in maternal mortality 2000 to 2020: estimates by WHO, UNICEF, UNFPA, World Bank Group and UNDESA/ Population Division. Geneva: World Health Organization; 2023. Licence: CC BY-NC-SA 3.0 IGO.

### WHO Mortality Database

The WHO mortality database is a collection death registration data including cause-of-death information from member states.

Where they are collected, death registration data are the best source of information on key health indicators, such as life expectancy, and death registration data with cause-of-death information are the best source of information on mortality by cause, such as maternal mortality and suicide mortality.

WHO requests from all countries annual data by age, sex, and complete ICD code (e.g., 4-digit code if the 10th revision of ICD was used). Countries have reported deaths by cause of death, year, sex, and age for inclusion in the WHO Mortality Database since 1950.

The WHO only includes data, which are properly coded according to the International Classification of Diseases (ICD). Today the database is maintained by the WHO Division of Data, Analytics and Delivery for Impact (DDI) and contains data from over 120 countries and areas. Data reported by member states and selected areas are displayed in this portal’s interactive visualizations if the data are reported to the WHO mortality database in the requested format and at least 65% of deaths were recorded in each country and year.

Producer: WHO Mortality Database  
Published: 2025-02-13  
Retrieved on: 2025-04-17  
Retrieved from: https://platform.who.int/mortality  
License: CC BY-NC-SA 3.0 IGO (https://www.who.int/about/policies/publishing/copyright)  

Citation: WHO Division of Data, Analytics and Delivery for Impact (DDI), World Health Organization (2024)

### United Nations – World Population Prospects

World Population Prospects 2024 is the 28th edition of the official estimates and projections of the global population that have been published by the United Nations since 1951. The estimates are based on all available sources of data on population size and levels of fertility, mortality and international migration for 237 countries or areas. If you have questions about this dataset, please refer to [their FAQ](https://population.un.org/wpp/faqs). You can also explore [data sources](https://population.un.org/wpp/data-sources) for each country or visit [their main page](https://population.un.org/wpp/) for more details.

Producer: United Nations  
Published: 2024-07-11  
Retrieved on: 2024-07-11  
Retrieved from: https://population.un.org/wpp/downloads/  
Direct download: https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/CSV_FILES/WPP2024_Fertility_by_Age5.csv.gz  
License: CC BY 3.0 IGO (https://population.un.org/wpp/downloads/)  

Citation: United Nations, Department of Economic and Social Affairs, Population Division (2024). World Population Prospects 2024, Online Edition.

### United Nations – World Population Prospects – Interim Update

World Population Prospects 2024 is the 28th edition of the official estimates and projections of the global population that have been published by the United Nations since 1951. The estimates are based on all available sources of data on population size and levels of fertility, mortality and international migration for 237 countries or areas. If you have questions about this dataset, please refer to [their FAQ](https://population.un.org/wpp/faqs). You can also explore [data sources](https://population.un.org/wpp/data-sources) for each country or visit [their main page](https://population.un.org/wpp/) for more details.

This is an interim update containing revised medium-variant estimates and projections for Togo.

Producer: United Nations  
Published: 2026-01-19  
Retrieved on: 2026-03-31  
Retrieved from: https://population.un.org/wpp/downloads/  
Direct download: https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/WPP2024_CSV_files_update.zip  
License: CC BY 3.0 IGO (https://population.un.org/wpp/downloads/)  

Citation: United Nations, Department of Economic and Social Affairs, Population Division (2024). World Population Prospects 2024, Online Edition.

### Gapminder – Maternal mortality ratio

Maternal Mortality is defined as a death of a woman while pregnant or within 42
days of termination of pregnancy, irrespective of the duration and site of pregnancy, from
any cause related or aggravated by the pregnancy or its management, but not from
accidental or incidental causes.
Maternal mortality ratio (usually abbreviated MMR) is the number of maternal deaths
during a given time period per 100,000 live births during the same time period

Producer: Gapminder  
Published: 2010-07-01  
Retrieved on: 2024-07-08  
Retrieved from: https://www.gapminder.org/data/documentation/gd010/  
Direct download: https://www.gapminder.org/documentation/documentation/gapdata010.xls  
License: CC BY 4.0 (https://www.gapminder.org/free-material/)  

Citation: Based on free material from GAPMINDER.ORG (https://www.gapminder.org/data/documentation/gd010/), CC-BY LICENSE

### Our World in Data – Regions

Producer: Our World in Data  

    